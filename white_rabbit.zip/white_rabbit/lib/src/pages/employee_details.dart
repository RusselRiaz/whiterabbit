import 'package:flutter/material.dart';

class EmployeeDetails extends StatefulWidget {

  String company;
  String email;
  String name;


  EmployeeDetails({Key? key, required this.company,required this.email,required this.name
    }) : super(key: key);

  @override
  _EmployeeDetailsState createState() => _EmployeeDetailsState();
}

class _EmployeeDetailsState extends State<EmployeeDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.name),
      ),
      body: Column(
        children: [
          Row(
            children: [
              Text(widget.company),
              Text(widget.email),
            ],
          )
        ],
      ),
    );
  }
}
