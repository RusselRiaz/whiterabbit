import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:white_rabbit/src/pages/employee_details.dart';
import 'dart:convert';
import 'package:white_rabbit/src/providers/db_provider.dart';
import 'package:white_rabbit/src/providers/employee_api_provider.dart';
import 'package:white_rabbit/src/models/employee_data.dart';

class FetchEmployee extends StatefulWidget {
  const FetchEmployee({Key? key}) : super(key: key);

  @override
  _FetchEmployeeState createState() => _FetchEmployeeState();
}

class _FetchEmployeeState extends State<FetchEmployee> {

  var isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Api to sqlite'),
        centerTitle: true,
        actions: <Widget>[
          Container(
            padding: EdgeInsets.only(right: 10.0),
            child: IconButton(
              icon: Icon(Icons.settings_input_antenna),
              onPressed: () async {
                await _loadFromApi();
              },
            ),
          ),
        ],
      ),
      body: isLoading
          ? Center(
        child: CircularProgressIndicator(),
      )
          : _buildEmployeeListView(),
    );
  }

  _loadFromApi() async {
    setState(() {
      isLoading = true;
    });

    var apiProvider = EmployeeApiProvider();
    await apiProvider.getAllEmployees();

    // wait for 2 seconds to simulate loading of data
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      isLoading = false;
    });
  }


  _buildEmployeeListView() {
    return FutureBuilder(
      future: DBProvider.db.getAllEmployees(),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        if (!snapshot.hasData) {
          return Center(
            child: CircularProgressIndicator(),
          );
        } else {
          return ListView.separated(
            separatorBuilder: (context, index) => Divider(
              color: Colors.black12,
            ),
            itemCount: snapshot.data.length,
            itemBuilder: (BuildContext context, int index) {
              return GestureDetector(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => EmployeeDetails(company: snapshot.data[index],
                      email: snapshot.data[index],
                      name: snapshot.data[index])));
                },
                child: ListTile(
                  leading: Text(
                    "${index + 1}",
                    style: TextStyle(fontSize: 20.0),
                  ),
                  title: Text(
                      "Name: ${snapshot.data[index].Name}"),
                ),
              );
            },
          );
        }
      },
    );
  }

}
