package com.example.white_rabbit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
